import { useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useApp } from '../AppContext';

export default function Auth({ mode }) {
  const isLogin = mode === 'login';
  const { login } = useApp();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password || (!isLogin && !form.name.trim())) return setError('Please fill in all fields.');
    try { login((await api.post(`/auth/${mode}`, form)).data); } catch (err) { setError(errMsg(err)); }
  };

  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <div className="hidden flex-col justify-center bg-indigo-600 p-12 text-white md:flex">
        <h1 className="text-4xl font-bold">TaskFlow</h1>
        <p className="mt-3 max-w-sm text-indigo-100">Plan projects with your team, assign tasks, talk inside each task and see changes as they happen.</p>
        <ul className="mt-6 space-y-2 text-sm text-indigo-100"><li>✓ Kanban boards for every project</li><li>✓ Assign tasks and set due dates</li><li>✓ Comments and live notifications</li></ul>
      </div>
      <div className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="card w-full max-w-sm space-y-4 p-6">
          <h2 className="text-xl font-semibold">{isLogin ? 'Welcome back' : 'Create your account'}</h2>
          {error && <p className="rounded bg-red-50 p-2 text-sm text-red-700">{error}</p>}
          {!isLogin && <div><label className="label">Full name</label><input className="input" value={form.name} onChange={set('name')} /></div>}
          <div><label className="label">Email</label><input type="email" className="input" value={form.email} onChange={set('email')} /></div>
          <div><label className="label">Password</label><input type="password" className="input" value={form.password} onChange={set('password')} /></div>
          <button className="btn w-full">{isLogin ? 'Login' : 'Register'}</button>
          <p className="text-sm text-slate-600">{isLogin ? 'New here?' : 'Already registered?'} <Link className="text-indigo-600 underline" to={isLogin ? '/register' : '/login'}>{isLogin ? 'Create an account' : 'Login'}</Link></p>
        </form>
      </div>
    </div>
  );
}
