import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';

export default function Dashboard() {
  const [projects, setProjects] = useState(null);
  const [form, setForm] = useState({ name: '', description: '' });
  const [error, setError] = useState('');

  const load = () => api.get('/projects').then((r) => setProjects(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const create = async (e) => {
    e.preventDefault();
    try { await api.post('/projects', form); setForm({ name: '', description: '' }); setError(''); load(); } catch (err) { setError(errMsg(err)); }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="text-2xl font-bold">Your projects</h1>
      <form onSubmit={create} className="card my-5 flex flex-col gap-3 p-4 sm:flex-row">
        <input className="input sm:w-56" placeholder="Project name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="input flex-1" placeholder="Short description (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <button className="btn">Create project</button>
      </form>
      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}
      {!projects ? <p className="text-slate-500">Loading projects...</p> : projects.length === 0 ? <p className="text-slate-500">No projects yet. Create your first one above.</p> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => {
            const pct = p.total ? Math.round((p.done / p.total) * 100) : 0;
            return (
              <Link key={p._id} to={`/projects/${p._id}`} className="card border-t-4 border-t-indigo-500 p-4 transition-shadow hover:shadow-md">
                <h2 className="font-semibold">{p.name}</h2>
                <p className="mt-1 line-clamp-2 min-h-[2.5rem] text-sm text-slate-500">{p.description || 'No description'}</p>
                <div className="mt-3 h-1.5 rounded bg-slate-200"><div className="h-1.5 rounded bg-emerald-500" style={{ width: `${pct}%` }} /></div>
                <p className="mt-2 text-xs text-slate-500">{p.done}/{p.total} tasks done · {p.members.length} member(s)</p>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
