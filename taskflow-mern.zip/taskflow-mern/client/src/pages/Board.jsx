import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useApp } from '../AppContext';
import TaskModal from '../components/TaskModal';

const columns = [
  { key: 'todo', title: 'To Do', color: 'border-t-slate-400' },
  { key: 'doing', title: 'In Progress', color: 'border-t-amber-400' },
  { key: 'done', title: 'Done', color: 'border-t-emerald-500' },
];
export const priorityBar = { high: 'border-l-red-500', medium: 'border-l-amber-400', low: 'border-l-sky-400' };

export default function Board() {
  const { id } = useParams();
  const { user, socket } = useApp();
  const navigate = useNavigate();
  const [project, setProject] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [openId, setOpenId] = useState(null);
  const [newTitle, setNewTitle] = useState({});
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const upsert = (t) => setTasks((l) => (l.some((x) => x._id === t._id) ? l.map((x) => (x._id === t._id ? t : x)) : [...l, t]));

  useEffect(() => {
    api.get(`/projects/${id}`).then((r) => { setProject(r.data.project); setTasks(r.data.tasks); }).catch((e) => setError(errMsg(e)));
  }, [id]);

  useEffect(() => {
    if (!socket) return;
    socket.emit('join', id);
    const onMember = (m) => setProject((p) => (p.members.some((x) => x.user._id === m.user._id) ? p : { ...p, members: [...p.members, m] }));
    const onDelete = (t) => { setTasks((l) => l.filter((x) => x._id !== t._id)); setOpenId((o) => (o === t._id ? null : o)); };
    socket.on('task:created', upsert); socket.on('task:updated', upsert); socket.on('task:deleted', onDelete); socket.on('member:added', onMember);
    return () => { socket.emit('leave', id); socket.off('task:created', upsert); socket.off('task:updated', upsert); socket.off('task:deleted', onDelete); socket.off('member:added', onMember); };
  }, [socket, id]);

  const addTask = async (e, status) => {
    e.preventDefault();
    const title = (newTitle[status] || '').trim();
    if (!title) return;
    try { upsert((await api.post(`/projects/${id}/tasks`, { title, status })).data); setNewTitle({ ...newTitle, [status]: '' }); } catch (err) { setError(errMsg(err)); }
  };
  const move = async (taskId, status) => {
    const t = tasks.find((x) => x._id === taskId);
    if (!t || t.status === status) return;
    upsert({ ...t, status }); // update the screen first, then save
    try { upsert((await api.patch(`/tasks/${taskId}`, { status })).data); } catch (err) { upsert(t); setError(errMsg(err)); }
  };
  const invite = async (e) => {
    e.preventDefault();
    try { const { data } = await api.post(`/projects/${id}/members`, { email }); setProject((p) => (p.members.some((x) => x.user._id === data.user._id) ? p : { ...p, members: [...p.members, data] })); setEmail(''); setError(''); } catch (err) { setError(errMsg(err)); }
  };
  const remove = async () => {
    if (!confirm('Delete this project and all its tasks?')) return;
    try { await api.delete(`/projects/${id}`); navigate('/'); } catch (err) { setError(errMsg(err)); }
  };

  if (!project) return <p className="p-8 text-center text-slate-500">{error || 'Loading board...'}</p>;
  const isOwner = project.owner === user._id;
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <Link to="/" className="text-sm text-indigo-600 hover:underline">← All projects</Link>
      <div className="mt-2 flex flex-wrap items-start justify-between gap-3">
        <div><h1 className="text-2xl font-bold">{project.name}</h1><p className="text-sm text-slate-500">{project.description}</p></div>
        {isOwner && <button onClick={remove} className="text-sm text-red-600 hover:underline">Delete project</button>}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {project.members.map((m) => <span key={m.user._id} title={m.user.email} className="rounded-full bg-indigo-100 px-3 py-1 text-xs font-medium text-indigo-700">{m.user.name}{m.role === 'owner' ? ' (owner)' : ''}</span>)}
        <form onSubmit={invite} className="flex gap-2"><input className="input w-48 py-1" placeholder="Invite by email" value={email} onChange={(e) => setEmail(e.target.value)} /><button className="btn-ghost">Add</button></form>
      </div>
      {error && <p className="mt-3 rounded bg-red-50 p-2 text-sm text-red-700">{error}</p>}

      <div className="mt-5 grid gap-4 md:grid-cols-3">
        {columns.map((col) => {
          const list = tasks.filter((t) => t.status === col.key);
          return (
            <div key={col.key} onDragOver={(e) => e.preventDefault()} onDrop={(e) => move(e.dataTransfer.getData('id'), col.key)} className={`rounded-lg border-t-4 bg-slate-200/70 p-3 ${col.color}`}>
              <h2 className="mb-3 flex justify-between text-sm font-semibold">{col.title}<span className="rounded-full bg-white px-2 text-xs text-slate-500">{list.length}</span></h2>
              <div className="space-y-2">
                {list.map((t) => (
                  <div key={t._id} draggable onDragStart={(e) => e.dataTransfer.setData('id', t._id)} onClick={() => setOpenId(t._id)}
                    className={`card cursor-pointer border-l-4 p-3 text-sm hover:shadow-md ${priorityBar[t.priority]}`}>
                    <p className="font-medium">{t.title}</p>
                    <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
                      <span className={t.dueDate && t.dueDate.slice(0, 10) < today && t.status !== 'done' ? 'font-semibold text-red-600' : ''}>{t.dueDate ? `Due ${new Date(t.dueDate).toLocaleDateString('en-IN')}` : ''}</span>
                      {t.assignee && <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-indigo-700">{t.assignee.name.split(' ')[0]}</span>}
                    </div>
                  </div>
                ))}
              </div>
              <form onSubmit={(e) => addTask(e, col.key)} className="mt-3"><input className="input py-1.5" placeholder="+ Add a task" value={newTitle[col.key] || ''} onChange={(e) => setNewTitle({ ...newTitle, [col.key]: e.target.value })} /></form>
            </div>
          );
        })}
      </div>
      {openId && <TaskModal taskId={openId} members={project.members} onClose={() => setOpenId(null)} onUpdate={upsert} />}
    </div>
  );
}
