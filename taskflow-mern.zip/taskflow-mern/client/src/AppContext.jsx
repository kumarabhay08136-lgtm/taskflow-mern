import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import api from './api';

const Ctx = createContext();
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));
  const [socket, setSocket] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [toast, setToast] = useState('');

  const login = ({ token, user }) => { localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user)); setUser(user); };
  const logout = () => { localStorage.clear(); setUser(null); };
  const markRead = () => { api.post('/notifications/read'); setNotifications((l) => l.map((n) => ({ ...n, read: true }))); };

  useEffect(() => {
    if (!user) { setSocket(null); setNotifications([]); return; }
    const s = io({ auth: { token: localStorage.getItem('token') } });
    s.on('notification', (n) => {
      setNotifications((l) => [n, ...l]);
      setToast(n.message);
      setTimeout(() => setToast(''), 4000);
    });
    api.get('/notifications').then((r) => setNotifications(r.data)).catch(() => {});
    setSocket(s);
    return () => s.disconnect();
  }, [user]);

  return <Ctx.Provider value={{ user, login, logout, socket, notifications, markRead, toast }}>{children}</Ctx.Provider>;
}
