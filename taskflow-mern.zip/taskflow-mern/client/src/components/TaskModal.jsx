import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useApp } from '../AppContext';

export default function TaskModal({ taskId, members, onClose, onUpdate }) {
  const { user, socket } = useApp();
  const [task, setTask] = useState(null);
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    api.get(`/tasks/${taskId}`).then((r) => { setTask(r.data.task); setComments(r.data.comments); }).catch((e) => setError(errMsg(e)));
  }, [taskId]);

  useEffect(() => {
    if (!socket) return;
    const added = (c) => c.task === taskId && setComments((l) => (l.some((x) => x._id === c._id) ? l : [...l, c]));
    const removed = (c) => setComments((l) => l.filter((x) => x._id !== c._id));
    socket.on('comment:created', added); socket.on('comment:deleted', removed);
    return () => { socket.off('comment:created', added); socket.off('comment:deleted', removed); };
  }, [socket, taskId]);

  const save = async (changes) => {
    try { const { data } = await api.patch(`/tasks/${taskId}`, changes); setTask(data); onUpdate(data); setError(''); } catch (e) { setError(errMsg(e)); }
  };
  const addComment = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    try { const { data } = await api.post(`/tasks/${taskId}/comments`, { body: text }); setComments((l) => (l.some((x) => x._id === data._id) ? l : [...l, data])); setText(''); } catch (err) { setError(errMsg(err)); }
  };
  const delComment = async (id) => { try { await api.delete(`/comments/${id}`); setComments((l) => l.filter((c) => c._id !== id)); } catch (e) { setError(errMsg(e)); } };
  const delTask = async () => { if (confirm('Delete this task?')) { try { await api.delete(`/tasks/${taskId}`); onClose(); } catch (e) { setError(errMsg(e)); } } };

  return (
    <div className="fixed inset-0 z-30 flex items-start justify-center overflow-y-auto bg-slate-900/50 p-4" onClick={onClose}>
      <div className="card my-8 w-full max-w-2xl p-5" onClick={(e) => e.stopPropagation()}>
        {!task ? <p className="text-slate-500">{error || 'Loading task...'}</p> : (
          <>
            <div className="flex items-start justify-between gap-3">
              <input key={task.title} className="w-full text-xl font-semibold focus:outline-none" defaultValue={task.title} onBlur={(e) => e.target.value.trim() && e.target.value !== task.title && save({ title: e.target.value })} />
              <button onClick={onClose} className="text-xl text-slate-400 hover:text-slate-700" aria-label="Close">✕</button>
            </div>
            {error && <p className="my-2 rounded bg-red-50 p-2 text-sm text-red-700">{error}</p>}
            <div className="my-4 grid gap-3 sm:grid-cols-4">
              <div><label className="label">Status</label><select className="input" value={task.status} onChange={(e) => save({ status: e.target.value })}><option value="todo">To Do</option><option value="doing">In Progress</option><option value="done">Done</option></select></div>
              <div><label className="label">Priority</label><select className="input" value={task.priority} onChange={(e) => save({ priority: e.target.value })}><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></div>
              <div><label className="label">Assignee</label><select className="input" value={task.assignee?._id || ''} onChange={(e) => save({ assignee: e.target.value })}><option value="">Unassigned</option>{members.map((m) => <option key={m.user._id} value={m.user._id}>{m.user.name}</option>)}</select></div>
              <div><label className="label">Due date</label><input type="date" className="input" value={task.dueDate ? task.dueDate.slice(0, 10) : ''} onChange={(e) => save({ dueDate: e.target.value })} /></div>
            </div>
            <label className="label">Description</label>
            <textarea rows="3" className="input" placeholder="Add more details..." defaultValue={task.description} onBlur={(e) => e.target.value !== task.description && save({ description: e.target.value })} />
            <h3 className="mb-2 mt-5 font-semibold">Comments ({comments.length})</h3>
            <div className="space-y-2">
              {comments.length === 0 && <p className="text-sm text-slate-500">No comments yet.</p>}
              {comments.map((c) => (
                <div key={c._id} className="rounded-md bg-slate-50 p-2 text-sm">
                  <div className="flex justify-between text-xs text-slate-500"><span><b className="text-slate-700">{c.user.name}</b> · {new Date(c.createdAt).toLocaleString('en-IN')}</span>{c.user._id === user._id && <button className="text-red-500" onClick={() => delComment(c._id)}>Delete</button>}</div>
                  <p className="mt-1">{c.body}</p>
                </div>
              ))}
            </div>
            <form onSubmit={addComment} className="mt-3 flex gap-2"><input className="input" placeholder="Write a comment..." value={text} onChange={(e) => setText(e.target.value)} /><button className="btn">Send</button></form>
            <button onClick={delTask} className="mt-4 text-sm text-red-600 hover:underline">Delete task</button>
          </>
        )}
      </div>
    </div>
  );
}
