import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../AppContext';

export default function Navbar() {
  const { user, logout, notifications, markRead } = useApp();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const unread = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-20 bg-slate-900 text-white">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2 text-lg font-bold"><span className="rounded bg-indigo-500 px-2 py-0.5 text-sm">TF</span> TaskFlow</Link>
        <div className="flex items-center gap-4 text-sm">
          <div className="relative">
            <button onClick={() => { setOpen(!open); if (!open && unread) markRead(); }} className="relative rounded px-2 py-1 hover:bg-slate-800" aria-label="Notifications">
              🔔{unread > 0 && <span className="absolute -right-1 -top-1 rounded-full bg-red-500 px-1.5 text-xs">{unread}</span>}
            </button>
            {open && (
              <div className="absolute right-0 mt-2 max-h-80 w-72 overflow-y-auto rounded-md border bg-white text-slate-800 shadow-lg">
                {notifications.length === 0 ? <p className="p-3 text-sm text-slate-500">No notifications yet.</p> : notifications.map((n) => (
                  <button key={n._id} onClick={() => { setOpen(false); n.project && navigate(`/projects/${n.project}`); }} className="block w-full border-b px-3 py-2 text-left text-sm last:border-0 hover:bg-slate-50">
                    <p className={n.read ? '' : 'font-semibold'}>{n.message}</p>
                    <p className="text-xs text-slate-400">{new Date(n.createdAt).toLocaleString('en-IN')}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
          <span className="hidden text-slate-300 sm:inline">{user.name}</span>
          <button onClick={logout} className="text-slate-400 hover:text-white">Logout</button>
        </div>
      </div>
    </header>
  );
}
