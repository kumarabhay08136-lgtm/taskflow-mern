import { Navigate, Route, Routes } from 'react-router-dom';
import { useApp } from './AppContext';
import Navbar from './components/Navbar';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import Board from './pages/Board';

const Private = ({ children }) => (useApp().user ? children : <Navigate to="/login" replace />);

export default function App() {
  const { user, toast } = useApp();
  return (
    <>
      {user && <Navbar />}
      <Routes>
        <Route path="/login" element={user ? <Navigate to="/" /> : <Auth mode="login" />} />
        <Route path="/register" element={user ? <Navigate to="/" /> : <Auth mode="register" />} />
        <Route path="/" element={<Private><Dashboard /></Private>} />
        <Route path="/projects/:id" element={<Private><Board /></Private>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      {toast && <div className="fixed bottom-4 right-4 z-50 max-w-xs rounded-md bg-slate-900 px-4 py-3 text-sm text-white shadow-lg">🔔 {toast}</div>}
    </>
  );
}
