require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { Server } = require('socket.io');
const { Project } = require('./models');

const app = express();
app.use(cors());
app.use(express.json());
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
app.set('io', io);

// WebSocket auth: same JWT as the REST API
io.use((socket, next) => {
  try { socket.userId = jwt.verify(socket.handshake.auth.token, process.env.JWT_SECRET).id; next(); }
  catch { next(new Error('unauthorized')); }
});
io.on('connection', (socket) => {
  socket.join(`user:${socket.userId}`); // personal room for notifications
  socket.on('join', async (projectId) => {
    try { if (await Project.exists({ _id: projectId, 'members.user': socket.userId })) socket.join(`project:${projectId}`); } catch {}
  });
  socket.on('leave', (projectId) => socket.leave(`project:${projectId}`));
});

app.use('/api', require('./routes'));
app.use((err, req, res, next) => {
  if (err.name === 'CastError') return res.status(404).json({ message: 'Not found.' });
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ message: err.status ? err.message : 'Something went wrong. Please try again.' });
});

mongoose.connect(process.env.MONGO_URI)
  .then(() => server.listen(process.env.PORT || 5000, () => console.log('TaskFlow server running')))
  .catch((e) => { console.error('MongoDB connection failed:', e.message); process.exit(1); });
