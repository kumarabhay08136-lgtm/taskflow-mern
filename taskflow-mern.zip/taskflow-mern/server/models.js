const mongoose = require('mongoose');
const { Schema } = mongoose;
const ref = (name) => ({ type: Schema.Types.ObjectId, ref: name });

const User = mongoose.model('User', new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
}, { timestamps: true }));

const Project = mongoose.model('Project', new Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  owner: ref('User'),
  members: [{ user: ref('User'), role: { type: String, enum: ['owner', 'member'], default: 'member' } }],
}, { timestamps: true }));

const Task = mongoose.model('Task', new Schema({
  project: { ...ref('Project'), index: true },
  title: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  status: { type: String, enum: ['todo', 'doing', 'done'], default: 'todo' },
  priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
  assignee: { ...ref('User'), default: null },
  dueDate: { type: Date, default: null },
  createdBy: ref('User'),
}, { timestamps: true }));

const Comment = mongoose.model('Comment', new Schema({
  task: { ...ref('Task'), index: true }, user: ref('User'), body: { type: String, required: true, trim: true },
}, { timestamps: true }));

const Notification = mongoose.model('Notification', new Schema({
  user: { ...ref('User'), index: true }, message: String, project: ref('Project'), task: ref('Task'), read: { type: Boolean, default: false },
}, { timestamps: true }));

module.exports = { User, Project, Task, Comment, Notification };
