const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, Project, Task, Comment, Notification } = require('./models');

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const fail = (status, message) => Object.assign(new Error(message), { status });
const session = (u) => ({ token: jwt.sign({ id: u._id }, process.env.JWT_SECRET, { expiresIn: '7d' }), user: { _id: u._id, name: u.name, email: u.email } });

const auth = wrap(async (req, res, next) => {
  let id;
  try { id = jwt.verify((req.headers.authorization || '').slice(7), process.env.JWT_SECRET).id; }
  catch { throw fail(401, 'Please log in again.'); }
  req.user = await User.findById(id);
  if (!req.user) throw fail(401, 'Please log in again.');
  next();
});

// Only members of a project can see or change anything inside it
const getProject = async (id, userId) => {
  const p = await Project.findOne({ _id: id, 'members.user': userId });
  if (!p) throw fail(404, 'Project not found.');
  return p;
};
const getTask = async (id, userId) => {
  const task = await Task.findById(id);
  if (!task) throw fail(404, 'Task not found.');
  return { task, project: await getProject(task.project, userId) };
};
const emit = (req, projectId, event, data) => req.app.get('io').to(`project:${projectId}`).emit(event, data);
const notify = async (req, userId, message, project, task) => {
  if (!userId || String(userId) === String(req.user._id)) return;
  const n = await Notification.create({ user: userId, message, project, task });
  req.app.get('io').to(`user:${userId}`).emit('notification', n);
};
const fullTask = (t) => Task.findById(t._id).populate('assignee', 'name email');

// ---- auth
router.post('/auth/register', wrap(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) throw fail(400, 'Name, email and password are required.');
  if (password.length < 6) throw fail(400, 'Password must be at least 6 characters.');
  if (await User.findOne({ email: email.toLowerCase() })) throw fail(400, 'This email is already registered.');
  res.status(201).json(session(await User.create({ name, email, password: await bcrypt.hash(password, 10) })));
}));
router.post('/auth/login', wrap(async (req, res) => {
  const u = req.body.email && (await User.findOne({ email: req.body.email.toLowerCase() }));
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password))) throw fail(401, 'Invalid email or password.');
  res.json(session(u));
}));

router.use(auth);

// ---- projects
router.get('/projects', wrap(async (req, res) => {
  const projects = await Project.find({ 'members.user': req.user._id }).sort({ updatedAt: -1 }).lean();
  for (const p of projects) {
    p.total = await Task.countDocuments({ project: p._id });
    p.done = await Task.countDocuments({ project: p._id, status: 'done' });
  }
  res.json(projects);
}));
router.post('/projects', wrap(async (req, res) => {
  if (!req.body.name?.trim()) throw fail(400, 'Project name is required.');
  res.status(201).json(await Project.create({
    name: req.body.name, description: req.body.description, owner: req.user._id, members: [{ user: req.user._id, role: 'owner' }],
  }));
}));
router.get('/projects/:id', wrap(async (req, res) => {
  const project = await (await getProject(req.params.id, req.user._id)).populate('members.user', 'name email');
  res.json({ project, tasks: await Task.find({ project: project._id }).sort('createdAt').populate('assignee', 'name email') });
}));
router.delete('/projects/:id', wrap(async (req, res) => {
  const p = await getProject(req.params.id, req.user._id);
  if (String(p.owner) !== String(req.user._id)) throw fail(403, 'Only the project owner can delete it.');
  const ids = (await Task.find({ project: p._id }, '_id')).map((t) => t._id);
  await Comment.deleteMany({ task: { $in: ids } });
  await Task.deleteMany({ project: p._id });
  await p.deleteOne();
  res.json({ message: 'Project deleted.' });
}));
router.post('/projects/:id/members', wrap(async (req, res) => {
  const p = await getProject(req.params.id, req.user._id);
  const u = await User.findOne({ email: (req.body.email || '').toLowerCase() });
  if (!u) throw fail(404, 'No user found with that email. They need to register first.');
  if (p.members.some((m) => String(m.user) === String(u._id))) throw fail(400, 'Already a member of this project.');
  p.members.push({ user: u._id });
  await p.save();
  const member = { user: { _id: u._id, name: u.name, email: u.email }, role: 'member' };
  emit(req, p._id, 'member:added', member);
  await notify(req, u._id, `${req.user.name} added you to "${p.name}"`, p._id);
  res.status(201).json(member);
}));

// ---- tasks
router.post('/projects/:id/tasks', wrap(async (req, res) => {
  const p = await getProject(req.params.id, req.user._id);
  if (!req.body.title?.trim()) throw fail(400, 'Task title is required.');
  const t = await Task.create({ project: p._id, title: req.body.title, status: req.body.status, createdBy: req.user._id });
  const task = await fullTask(t);
  emit(req, p._id, 'task:created', task);
  res.status(201).json(task);
}));
router.get('/tasks/:id', wrap(async (req, res) => {
  const { task } = await getTask(req.params.id, req.user._id);
  res.json({ task: await fullTask(task), comments: await Comment.find({ task: task._id }).sort('createdAt').populate('user', 'name') });
}));
router.patch('/tasks/:id', wrap(async (req, res) => {
  const { task, project } = await getTask(req.params.id, req.user._id);
  const before = { status: task.status, assignee: String(task.assignee || '') };
  for (const f of ['title', 'description', 'status', 'priority', 'dueDate'])
    if (req.body[f] !== undefined) task[f] = req.body[f] || (f === 'dueDate' ? null : task[f]);
  if (req.body.assignee !== undefined) {
    if (req.body.assignee && !project.members.some((m) => String(m.user) === req.body.assignee)) throw fail(400, 'Assignee must be a project member.');
    task.assignee = req.body.assignee || null;
  }
  await task.save();
  const updated = await fullTask(task);
  emit(req, project._id, 'task:updated', updated);
  if (String(task.assignee || '') !== before.assignee) await notify(req, task.assignee, `${req.user.name} assigned you "${task.title}"`, project._id, task._id);
  else if (task.status !== before.status) await notify(req, task.assignee, `"${task.title}" moved to ${task.status}`, project._id, task._id);
  res.json(updated);
}));
router.delete('/tasks/:id', wrap(async (req, res) => {
  const { task, project } = await getTask(req.params.id, req.user._id);
  await Comment.deleteMany({ task: task._id });
  await task.deleteOne();
  emit(req, project._id, 'task:deleted', { _id: task._id });
  res.json({ message: 'Task deleted.' });
}));

// ---- comments
router.post('/tasks/:id/comments', wrap(async (req, res) => {
  const { task, project } = await getTask(req.params.id, req.user._id);
  if (!req.body.body?.trim()) throw fail(400, 'Comment cannot be empty.');
  const c = await (await Comment.create({ task: task._id, user: req.user._id, body: req.body.body })).populate('user', 'name');
  emit(req, project._id, 'comment:created', c);
  for (const uid of new Set([String(task.assignee || ''), String(task.createdBy)]))
    await notify(req, uid || null, `${req.user.name} commented on "${task.title}"`, project._id, task._id);
  res.status(201).json(c);
}));
router.delete('/comments/:id', wrap(async (req, res) => {
  const c = await Comment.findOne({ _id: req.params.id, user: req.user._id });
  if (!c) throw fail(404, 'Comment not found.');
  const task = await Task.findById(c.task);
  await c.deleteOne();
  emit(req, task.project, 'comment:deleted', { _id: c._id, task: c.task });
  res.json({ message: 'Comment deleted.' });
}));

// ---- notifications
router.get('/notifications', wrap(async (req, res) => res.json(await Notification.find({ user: req.user._id }).sort('-createdAt').limit(30))));
router.post('/notifications/read', wrap(async (req, res) => {
  await Notification.updateMany({ user: req.user._id, read: false }, { read: true });
  res.json({ message: 'ok' });
}));

module.exports = router;
